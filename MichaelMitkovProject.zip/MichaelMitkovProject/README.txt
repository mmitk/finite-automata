name: Michael Mitkov


to run the program all that needs to be done is:

python main.py 

however python 3.6 is required I am not sure what the results will 
be with lower versions.

python -3 main.py

is a safe alternative.

When running main.py, you will be asked whether you will be providing
your own input for the examples, press 'y' or 'n'.
if you press 'y' each example will first ask you if you want to see the next 
one or skip it, amd then ask you for an input after a brief description
of the example.
For some examples, such as the NFA's there is quite alot of output,
especially if you choose not to provide your own input.
I have provided an output.txt, this shows the output of all the prewritten
examples I have written to demonstrate the program.